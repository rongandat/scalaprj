	<ul id="menu-top" class="menu">
		<li><a href="<?php echo home_url(); ?>">Home</a></li>
	</ul>