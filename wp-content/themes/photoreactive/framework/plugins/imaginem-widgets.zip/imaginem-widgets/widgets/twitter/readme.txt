=== Recent Tweets Widget ===
Contributors: themeprince
Donate link: http://themeprince.com/
Tags: recent tweets, twitter widget, twitter api v1.1, cache
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
