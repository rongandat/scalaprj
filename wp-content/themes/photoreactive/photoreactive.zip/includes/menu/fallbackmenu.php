<ul id="menu-top" class="menu">
<li><a href="<?php echo home_url(); ?>">
<div class="mtheme-menu-not-found">Menu not found. Use Menu Builder in WP-ADMIN</div></a>
</li>
</ul>