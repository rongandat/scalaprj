jQuery(window).bind("load", function() {
	jQuery('.preload-image:hidden').fadeIn(800);
});